import axios from 'axios'

const ADMIN_URL ="http://localhost:8000/advertise";

class AdvertisementService {

    viewAdvertisements(){
        return axios.get(ADMIN_URL+'/viewAdvertisements');
    }
}
export default new AdvertisementService()