import React, {Component} from 'react'
import AdvertisementService from '../Service/AdvertisementService';
import {Link} from 'react-router-dom'
export class viewAdvertisements extends Component{
    constructor(props){
        super(props)
        this.state={
            products:[]
        };
    }
    componentDidMount(){
        AdvertisementService.viewAdvertisements().then((res)=>{
            this.setState({products:res.data});
        });
    }
    render(){
        return(

            <div>
            <div className="position">
              <h2>Advertisement Details</h2>
            </div>
            <center>
            <div className="tableposition">
              <table class="table table-bordered " >
                <thead class="table-dark">
                  <tr>
                    <th>AdTitle</th>
                    <th>AdType</th>
                    <th>Description</th>
                    <th>Booking Date</th>
                    <th>Expiry Date</th>
                    <th>Address</th>
                    <th>Phone No.</th>
                    <th>Company Name</th>
                    <th >Email</th>
                    <th>Amount</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody class="table-light">
                  {
                    this.state.products.map(
                      product =>
                        <tr class="first active-row">
                         <td>{product.adTitle}</td>
                          <td> {product.adType} </td>
                          <td> {product.description}</td>
                          <td> {product.bookingDate}</td>
                          <td> {product.expiryDate}</td>
                          <td> {product.address}</td>
                          <td> {product.phoneNo}</td>
                          <td> {product.companyName}</td>
                          <td> {product.email}</td>
                          <td> {product.amount}</td>
                          <td>
                          <button type="button" class="btn btn-success ">Advertise</button>
                          <button type="button" class="btn btn-danger ">Delete</button> 
                        </td>
                        </tr>
                    )
                  }
                </tbody>
              </table>
            </div>
            </center>
          </div>
        )
    }
}
export default viewAdvertisements