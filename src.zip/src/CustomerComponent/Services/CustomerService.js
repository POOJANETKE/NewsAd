import axios from 'axios';

const CUSTOMER_API_BASE_URL = "http://localhost:8080/news";

class CustomerService {

    UserLogin(emailId,password){
        return axios.get(CUSTOMER_API_BASE_URL+'/customer'+emailId+'/'+password)
    }
   
}
export default new CustomerService()