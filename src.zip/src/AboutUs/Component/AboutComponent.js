import React from 'react'
import '../Css/about.css'

function AboutComponent() {
    return (
      
        <div id="main_content">
        <br/>
         <div class="top-left">
             <br></br>
             <h2><u>About Us</u></h2>
             <span>
             Advertisement management system project is a complete online solution for advertisers who want to advertise their product on online media or websites. Advertisement Management System project is developed using Spring Boot, ReactJs and Postgres. This project is developed for the users who want to manage their online advertisement from one place. This website is very helpful to advertisement agency staffs and managers to manage advertisements and to view reports. 
             </span>
        </div>
        </div>
       
    )
}

export default AboutComponent